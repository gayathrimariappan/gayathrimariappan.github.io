package org.administrator;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="ORDER_PLACED_DETAILS")
public class OrderPlacedDetails {
	@Column(name="SHIPPED_DATE")
	private Date shippedDate;
	@Column(name="DELIVERY_DATE")
	private Date deliveryDate;
	@Column(name="PRODUCT_NAME")
	private String productName;
	@Column(name="PRODUCT_QUANTITY")
	private int productQuantiy;
	@Column(name="PRODUCT_PRICE")
	private float productPrice;
	@Column(name="PAYMENT_METHOD")
	private String paymentMethod;
	public Date getShippedDate() {
		return shippedDate;
	}
	public void setShippedDate(Date shippedDate) {
		this.shippedDate = shippedDate;
	}
	public Date getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(Date deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductQuantiy() {
		return productQuantiy;
	}
	public void setProductQuantiy(int productQuantiy) {
		this.productQuantiy = productQuantiy;
	}
	public float getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}
	
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public OrderPlacedDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
