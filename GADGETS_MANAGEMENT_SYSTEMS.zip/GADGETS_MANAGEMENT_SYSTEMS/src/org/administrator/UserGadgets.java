package org.administrator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "USER_GADGETS")
public class UserGadgets {
	@Id
	@Column(name = "USER_NAME")
	private String userName;
	@Column(name = "GADGETS")
	private String gadgets;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getGadgets() {
		return gadgets;
	}

	public void setGadgets(String gadgets) {
		this.gadgets = gadgets;
	}

	public UserGadgets() {
		super();
		// TODO Auto-generated constructor stub
	}

}
