package org.administrator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "GADGET_STOCK_DETAILS")
public class GadgetStockDetails {
	@Id
	@Column(name="PRODUCT_ID",nullable=false,updatable=false)
	private String productId;
	@Column(name = "PRODUCT_NAME")
	private String productName;
	@Column(name = "PRODUCT_QUANTITY")
	private int productQuantity;
	@Column(name = "PRODUCT_STOCK")
	private int productStock;

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public int getProductStock() {
		return productStock;
	}

	public void setProductStock(int productStock) {
		this.productStock = productStock;
	}

	public GadgetStockDetails() {
		super();
	}

}
