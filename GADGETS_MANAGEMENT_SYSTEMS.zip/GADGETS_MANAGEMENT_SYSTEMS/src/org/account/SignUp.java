package org.account;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SIGN_UP")
public class SignUp {
	@Id
	@Column(name = "NAME")
	private String name;
	@Column(name = "USER_NAME",updatable=false,nullable=false)
	private String userName;
	@Column(name = "PASSWORD")
	private String password;
	@Column(name = "EMAIL_ID")
	private String emailId;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public SignUp() {
		super();
		// TODO Auto-generated constructor stub
	}

}
