package org.account;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "USER_STATUS")
public class UserStatus {
	@Id
	@Column(name = "ACTIVE")
	private boolean active;
	@Column(name = "AUTHENTICATED_USER")
	private boolean authenticatedUser;
	@Column(name = "NON_AUTHENTICATED_USER")
	private boolean nonAuthenticatedUser;

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isAuthenticatedUser() {
		return authenticatedUser;
	}

	public void setAuthenticatedUser(boolean authenticatedUser) {
		this.authenticatedUser = authenticatedUser;
	}

	public boolean isNonAuthenticatedUser() {
		return nonAuthenticatedUser;
	}

	public void setNonAuthenticatedUser(boolean nonAuthenticatedUser) {
		this.nonAuthenticatedUser = nonAuthenticatedUser;
	}

	public UserStatus() {
		super();
		// TODO Auto-generated constructor stub
	}

}
