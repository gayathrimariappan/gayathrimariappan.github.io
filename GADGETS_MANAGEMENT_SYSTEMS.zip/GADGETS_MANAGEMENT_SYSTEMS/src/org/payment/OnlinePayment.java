package org.payment;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="ONLINE_PAYMENT")
public class OnlinePayment {
	@Column(name="CREDIT_CARD_NUMBER",nullable=false,updatable=false)
	private long creditCardNumber;
	@Column(name="NET_AMOUNT")
	private float netAmount;
	@Column(name="PRODUCT_NAME")
	private String productName;
	@Column(name="PRODUCT_QUANTITY")
	private int productQuantity;
	public long getCreditCardNumber() {
		return creditCardNumber;
	}
	public void setCreditCardNumber(long creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
	public float getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(float netAmount) {
		this.netAmount = netAmount;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductQuantity() {
		return productQuantity;
	}
	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}
	public OnlinePayment() {
		super();
	}
	

}
